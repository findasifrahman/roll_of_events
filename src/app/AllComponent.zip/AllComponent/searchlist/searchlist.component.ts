import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import * as moment from 'moment'
import {fromEvent, Observable} from 'rxjs';
import {FormControl} from '@angular/forms';
import {map, startWith, take} from 'rxjs/operators';
import {myarr} from '../data'
import { EventService } from '../event/event.service'
import { routeurls } from '../../AllComponent/routeurls/routeurls'
import { BreakpointObserver } from '@angular/cdk/layout';
import { MatSidenav } from '@angular/material/sidenav';
@Component({
  selector: 'app-searchlist',
  templateUrl: './searchlist.component.html',
  styleUrls: ['./searchlist.component.scss']
})
export class SearchlistComponent implements OnInit {
  @ViewChild(MatSidenav) sidenav!: MatSidenav;


  recentlyUploaded = []
  allVideo = []
  public isMenuOpen: boolean = false;
  panelOpenState = false;
  imageEevent = []
  allevent = []/*[{id:1,title:"অনুভূতি amar amon", text:"BANGLA TEXT 1 jeta ektu boro but only 30 character nea hbe. tarpore sesh. pura jinista aro onek boro,er moddhe atbe kina ke jane xlick korle hobe", priority:1, date:moment().format('LLLL')},
  {id:2,title:"ক্লান্ত", text:"BANGLA TEXT 2", priority:2,date:moment().format('LLLL')},
  {id:3,title:"very tired", text:"BANGLA TEXT 3", priority:3, date:moment().format('LLLL')},
  {id:4,title:"inclusive", text:"BANGLA TEXT 4", priority:4, date:moment().format('LLLL')},
  {id:5,title:"nothing", text:"BANGLA TEXT 5", priority:5, date:moment().format('LLLL')},
  {id:6,title:"nothing2", text:"BANGLA TEXT 6", priority:6, date:moment().format('LLLL')}]*/

  searchtext = ""
  mainuri =  routeurls.BASE_API_URL + "/api/uploads/"//"http://localhost:5020/api/uploads/";
  image1 = ""
  filteredOptions: Observable<string[]>;
  planClient = new FormControl();
  textInput
  clients: string[] = [
    'Alabama',
    'California',
    'Colorado',
    'Connecticut',
    'SelectHealth',
    'UMR'
  ];
  permanentarr =[]
  totalImageno = 0
  constructor(private route: ActivatedRoute, public _router: Router,private eventService:EventService,private observer: BreakpointObserver) { 
    this._router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  ngOnInit(): void {
    /*this.clients = this.allevent.map(mapval=>{
      return mapval.title
    })*/
    this.clients = []
    for (let i = 0; i<20; i++){
      let ins = localStorage.getItem("usersearch" + i.toString())
      console.log("ins--", ins)
      if(ins)
        this.clients.push(ins)
    }
    this.route.params.subscribe(params => {
      this.searchtext = params['id'];
      console.log("searchtype--", params["id2"])
      if(params["id2"].includes("image")){
          this.showAllImage = true
          this.showallevent = false
          this.showAllVideo = false
      }else if(params["id2"].includes("video")){
        this.showAllImage = false
        this.showallevent = false
        this.showAllVideo = true
      }

      this.planClient.setValue(this.searchtext)
      if(this.searchtext.toLowerCase().includes("yearsearch")){
        this.showbyyear(this.searchtext.substr(11))
      }else if(this.searchtext.toLowerCase().includes("datesearch")){
        this.showbydate(this.searchtext.substr(11))
      }else{
            this.eventService.getAllbysearch(params['id']).subscribe((posts) => {
              this.permanentarr = posts
              console.log("posts.obj--", this.permanentarr)
              posts.map((mapval1,len1)=>{
              
                this.clients.push(mapval1.title)
                mapval1.image1 = this.mainuri +  mapval1.image1
                mapval1.indexx = len1
                mapval1.tdate=  moment(mapval1.date).format('LL')
                if(mapval1.title.length > 50){
                  mapval1.smtitle =  mapval1.title.substr(0,50) + " ..."
                }else{
                  mapval1.smtitle =  mapval1.title
                }
                this.totalImageno = this.totalImageno + 1
                /////////////////
                this.getImgSize(mapval1.image1 ).subscribe(val=>{
                  if(val.height > val.width){
                    mapval1.isverticle = true
                  }
                  else{
                    mapval1.isverticle = false
                  }
                  this.allevent.push(mapval1)
                  //this.allevent = this.allevent.splice(0,8)
                  if(mapval1.video){
                    mapval1.video = this.mainuri +  mapval1.video
                    this.allVideo.push(mapval1)
                  }
                  this.imageObject.push({image: mapval1.image1, title: mapval1.title})
                  //this.allVideo =  this.allevent//[]
                  this.imageEevent  =  this.allevent//[]
                  if(posts.length - 1 == len1){
                  
                  }
                  return mapval1.obj
                })
                //////////////////////


                /* if(posts.length -1 == len1){
                      //this.allevent = posts   
                      let priority = -1
                      let myobjj
                      let myaa = []
                      
                      this.searchtext = params['id'];
                      console.log("searchtext--", params['id']);
                      this.planClient.setValue(this.searchtext)


                      this.allevent =  myaa.sort(function(a, b){return b.priorityy - a.priorityy});
                      this.allevent = this.allevent.splice(0,8)
                      this.allVideo = []
                      this.imageEevent  = []

                      if(this.searchtext.toLowerCase().includes("category")){
                        if(this.searchtext.toLowerCase().includes("1971")){this.category71()}
                        else if(this.searchtext.toLowerCase().includes("1980")){this.category80()}
                        else if(this.searchtext.toLowerCase().includes("1990")){this.category90()}
                        else if(this.searchtext.toLowerCase().includes("2000")){this.category00()}
                        else if(this.searchtext.toLowerCase().includes("2010")){this.category10()}
                        else if(this.searchtext.toLowerCase().includes("2020")){this.category20()}
                      }else if(this.searchtext.toLowerCase().includes("recently")){
                        this.recentdata(posts.obj)
                      }else if(this.searchtext.toLowerCase().includes("yearsearch")){
                        this.showbyyear(this.searchtext.substr(11))
                      }else{
                        this.allevent.map((mapval,index)=>{

                          if(mapval.title.length > 120){
                            mapval.title = mapval.title.substr(0,120) + " ....."
                          }
                          ///////////

                          myobjj = mapval
                          myobjj.priorityy = priority 
                          
                          //if(myaa.length <8)
                          {
                            myaa.push(myobjj)
                          }
                          ///////////////
                          if(index == this.allevent.length -1){
                            this.allevent =  myaa.sort(function(a, b){return b.priorityy - a.priorityy});
                            this.allevent = this.allevent.splice(0,8)
                            this.allVideo = []
                            this.imageEevent  = []
                          // setTimeout(function()
                            {
                              let tempp = []
                              this.allevent.map((all,index)=>{
                                all.iid = index
                                this.imageObject.push({image: all.image1, title: all.title})
                                tempp.push(all)
                                if(all.video){
                                  all.video = this.mainuri +  all.video
                                  this.allVideo.push(all)
                                }
                                if(this.allevent.length - 1 == index){
                                  this.allevent = tempp
                                  this.imageEevent = tempp
                                }
                              })
                            }
                            //.bind(this),100)

                          }
                        })
                      }
                    }*/
                  //return mapval1.obj
                })
              
          })
      }
      //this.allevent = tempp.filter(x=> x != null )

    })
    
    ///////////////////
    this.planClient.valueChanges.subscribe()
    this.filteredOptions = this.planClient.valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
      );
    /////////////////////
  }
  ngAfterViewInit() {
    this.observer.observe(['(max-width: 800px)']).subscribe((res) => {
      if (res.matches) {
        this.sidenav.mode = 'over';
        this.sidenav.close();
      } else {
        this.sidenav.mode = 'side';
        this.sidenav.open();
      }
    });
  }
  private _filter(value: string): string[] {
    //console.log("insiede filter");
    const filterValue = value.toLowerCase();

    return this.clients.filter(clients => clients.toLowerCase().includes(filterValue));
  }
  FormSubmit(){
    //console.log("submitted", this.planClient.value)
    this._router.navigate(['/searchlist',  this.planClient.value, "all"])//this.planClient.value]);
    //this._router.navigate(['/searchlist', this.textInput]);
  }
  FormSubmit1(){
    this._router.navigate(['/searchlist', this.planClient.value,this.search_type]);
    //this._router.navigate(['/viewtemptwo', id]);
  }
  onDetail(id){
    this._router.navigate(['/viewtemptwo',id]);
  }
  gotoHome(){
    this._router.navigate(['/']);
  }
  recentdata(posts){
    this.planClient.setValue("recently:")

    let temparr = posts.sort(function(a, b){return new Date(b.uploadDate).getDate() - new Date(a.uploadDate).getDate()});
    let yu = []  
    this.imageObject = []
    this.allVideo = []
    for (var i = 0; i < temparr.length; i++) {
      if(temparr[i].title.length > 100)
        temparr[i].title = temparr[i].title.substr(0,100) + "..."
        
      temparr[i].iid = i
      this.imageObject.push({image: temparr[i].image1, title:  temparr[i].title})
        //temparr[i].image1 = this.mainuri  + temparr[i].image1
        //this.recentlyUploaded.push(temparr[i])
        yu.push(temparr[i])
        if(temparr[i].video){
          temparr[i].video = temparr[i].video
          this.allVideo.push(temparr[i])
        }
        if(i==10){
          //this.recentlyUploaded = yu
          this.allevent  = yu
          this.imageEevent = this.allevent
          //this._router.navigate(['/searchlist', "recently"]);
          break
        }
    }
  }
  recently(){
    this.recentdata(this.permanentarr)
  }
  showAllImage = false
  showAllVideo = false
  showallevent = true
  allView(){
    this.showAllImage = false
    this.showallevent = true
    this.showAllVideo = false
  }
  imageView(){
    this.showAllImage = true
    this.showallevent = false
    this.showAllVideo = false
  }
  videoView(){
    this.showAllImage = false
    this.showallevent = false
    this.showAllVideo = true
  }

  showFlag: boolean = false;
  selectedImageIndex: number = -1;
  imageObject=[]//: Array<object>
  showLightbox(index) {
    this.selectedImageIndex = index;
    this.showFlag = true;
  }
  closeEventHandler() {
    this.showFlag = false;
    this.selectedImageIndex = -1;
  }

  showbyyear(yeartext){
    this.eventService.getbyyear(yeartext).subscribe((posts) => {
      this.allevent = []
      this.imageObject = []
      this.allVideo = []
      this.totalImageno = 0
      posts.map((mapval,index) =>{
        mapval.image1 = this.mainuri +  mapval.image1
        mapval.indexx = index
        this.totalImageno = this.totalImageno + 1
        mapval.tdate=  moment(mapval.date).format('LL')
        if(mapval.title.length > 50){
          mapval.smtitle =  mapval.title.substr(0,50) + " ..."
        }else{
          mapval.smtitle =  mapval.title
        }

        //////////////////////////////////////
        this.getImgSize(mapval.image1 ).subscribe(val=>{
          if(val.height > val.width){
            mapval.isverticle = true
          }
          else{
            mapval.isverticle = false
          }
          this.allevent.push(mapval)
          //this.allevent = this.allevent.splice(0,8)
          if(mapval.video){
            mapval.video = this.mainuri +  mapval.video
            this.allVideo.push(mapval)
          }
          this.imageObject.push({image: mapval.image1, title: mapval.title})
          //this.allVideo =  this.allevent//[]
          this.imageEevent  =  this.allevent//[]
          
          return mapval.obj
        })
       /* this.allevent.push(mapval)

        if(mapval.video){
          mapval.video = this.mainuri +  mapval.video
          this.allVideo.push(mapval)
        }
        this.imageObject.push({image: mapval.image1, title: mapval.title})
        //this.allVideo =  this.allevent//[]
        //this.imageEevent  =  this.allevent//[]

        if(index == posts.length - 1){
          this.imageEevent = this.allevent    
        }*/
      })
    })
    console.log("yeartext--",yeartext)
  }
  showbydate(dt){
    this.eventService.getbydate(dt).subscribe((posts) => {
      this.allevent = []
      this.imageObject = []
      this.allVideo = []
      this.totalImageno = 0
      posts.map((mapval,index) =>{
        mapval.image1 = this.mainuri +  mapval.image1
        mapval.indexx = index
        this.totalImageno = this.totalImageno + 1
        mapval.tdate=  moment(mapval.date).format('LL')
        if(mapval.title.length > 50){
          mapval.smtitle =  mapval.title.substr(0,50) + " ..."
        }else{
          mapval.smtitle =  mapval.title
        }
        //////////////////////////////////////
        this.getImgSize(mapval.image1 ).subscribe(val=>{
          if(val.height > val.width){
            mapval.isverticle = true
          }
          else{
            mapval.isverticle = false
          }
          this.allevent.push(mapval)
          //this.allevent = this.allevent.splice(0,8)
          if(mapval.video){
            mapval.video = this.mainuri +  mapval.video
            this.allVideo.push(mapval)
          }
          this.imageObject.push({image: mapval.image1, title: mapval.title})
          //this.allVideo =  this.allevent//[]
          this.imageEevent  =  this.allevent//[]
          
          return mapval.obj
        })
        //////////////////////////////////////////////
        //this.allevent.push(mapval)

       /* if(mapval.video){
          mapval.video = this.mainuri +  mapval.video
          this.allVideo.push(mapval)
        }
        this.imageObject.push({image: mapval.image1, title: mapval.title})
        //this.allVideo =  this.allevent//[]
        //this.imageEevent  =  this.allevent//[]

        if(index == posts.length - 1){
          this.imageEevent = this.allevent    
        }*/
      })
    })
    console.log("yeartext--",dt)
  }
  dateval(id){
    this._router.navigate(['/searchlist', "datesearch:" + id, this.search_type])
  }


  _yearClick(param){
    //this._router.navigate(['/yearsearchresult', param]);
    console.log("paramm--", param)
    this._router.navigate(['/searchlist',  "yearsearch:" + param,"all"])//"yearsearch:" + param]);
  }
  searchBangabandhu(){
    this._router.navigate(['/searchlist', "Bangabandhu", "all"])//"Bangabandhu"]);
  }
  gotohome(){
    this._router.navigate(['/']);
  }
  display = "none";
  imageUrl = ""
  prevUrl = ""
  nextUrl = ""
  imageindex = 0
  isverticalmodal = false
  openModal() {
    let modal_t  = document.getElementById('modal_1')
    var modalImg = document.getElementById("img01");
    modal_t.style.display = "block";

    this.getImgSize(this.imageObject[this.imageindex].image ).subscribe(val=>{       
      if(val.height > val.width){
        this.isverticalmodal = true
      }else{
        this.isverticalmodal = false
      }
      this.imageUrl = this.imageObject[this.imageindex].image;
      var captionText = document.getElementById("caption");
      captionText.innerHTML = this.imageObject[this.imageindex].title;

      
      this.prevUrl = ""
      if(this.imageObject.length > 1){
        this.prevUrl = this.imageObject[this.imageObject.length -1].image;
      }
      if(this.imageObject.length > this.imageindex + 1)
        this.nextUrl = this.imageObject[this.imageindex + 1].image;
    })

    //this.display = "block";
  }
  modalclose(){
    let modal  = document.getElementById('modal_1')
    modal.style.display = "none";
    this.imageindex = 0
    
  }
  zoom_index =0
  zoomIn(){
    var modalImg = document.getElementById("img01");
    if(this.zoom_index == 0){
      modalImg.style.transform = "scale(1.2,1.2)"
      this.zoom_index = 1
    }else if(this.zoom_index == 1){
      modalImg.style.transform = "scale(1.4,1.4)"
      this.zoom_index = 2
    }else{
      modalImg.style.transform = "scale(1.6,1.6)"
      this.zoom_index = 3
    }
  }
  zoomOut(){
    var modalImg = document.getElementById("img01");
    if(this.zoom_index == 3){
      modalImg.style.transform = "scale(1.4,1.4)"
      this.zoom_index = 2
    }else if(this.zoom_index == 2){
      modalImg.style.transform = "scale(1.2,1.2)"
      this.zoom_index = 1
    }else{
      modalImg.style.transform = "scale(1,1)"
      this.zoom_index = 0
    }
  }
  downloadImage() {
 
                const a = document.createElement('a');
                a.href = this.imageUrl//URL.createObjectURL(res);
                a.download = this.imageUrl;
                document.body.appendChild(a);
                a.click();
           
  }
  plusSlides(){
    if(this.imageindex >= this.totalImageno - 1){
      let modal  = document.getElementById('modal_1')
      this.imageindex = 0
      modal.style.display = "none";
      
      
    }else{
      this.imageindex = this.imageindex + 1

      
      this.getImgSize(this.imageObject[this.imageindex].image ).subscribe(val=>{       
        if(val.height > val.width){
          this.isverticalmodal = true
        }else{
          this.isverticalmodal = false
        }
        this.imageUrl = this.imageObject[this.imageindex].image;
        var captionText = document.getElementById("caption");
        captionText.innerHTML = this.imageObject[this.imageindex].title;
      
        this.prevUrl =  this.imageObject[this.imageindex - 1].image
        if(this.imageObject.length > this.imageindex + 1)
          this.nextUrl = this.imageObject[this.imageindex + 1].image;
        if(this.imageObject.length == this.imageindex + 1){
          this.nextUrl = ""
          if(this.imageObject.length > 1){
            this.nextUrl = this.imageObject[0].image;
          }
        }

      })
    }

  }
  minusSlides(){
    if(this.imageindex > 0){
      this.imageindex = this.imageindex - 1

      this.getImgSize(this.imageObject[this.imageindex].image ).subscribe(val=>{       
        if(val.height > val.width){
          this.isverticalmodal = true
        }else{
          this.isverticalmodal = false
        }
        this.imageUrl = this.imageObject[this.imageindex].image;
        var captionText = document.getElementById("caption");
        captionText.innerHTML = this.imageObject[this.imageindex].title;


        if(this.imageObject.length > this.imageindex + 1)
          this.nextUrl = this.imageObject[this.imageindex + 1].image;
        if(this.imageindex == 0){
          this.prevUrl =  null
        }else{
          this.prevUrl =  this.imageObject[this.imageindex - 1].image
        }

      })
    }
    else{
      this.prevUrl =  ""
      if(this.imageObject.length > this.imageindex + 1)
        this.nextUrl = this.imageObject[this.imageindex + 1].image;
    }
  }
  @HostListener('window:keyup', ['$event'])
  keyEvent(event: KeyboardEvent) {
    let modal_t  = document.getElementById('modal_1')
    if(modal_t.style.display == "block")
    {
      if(event.key == 'ArrowLeft'){
        this.minusSlides()
        console.log("arroleft")
      }
      if(event.key == 'ArrowRight'){
        // Your row selection code
        this.plusSlides()
       console.log("arror")
      }
    }
  }

  bntStyle1: string = "btn-default";
  bntStyle2: string = "btn-default";
  search_type = "all"
  videoClick(){
    this.bntStyle1 = 'btn-default';
    this.bntStyle2 = 'btn-change';
    this.search_type = "video"
  }
  imageClick(){
    this.bntStyle1 = 'btn-change';
    this.bntStyle2 = 'btn-default';
    this.search_type = "image"
  }
  defaultClick(){
    this.bntStyle1 = 'btn-default';
    this.bntStyle2 = 'btn-default';
    this.search_type = "all"
  }
  getImgSize(imageSrc: string): Observable<any> {
    let mapLoadedImage = (event): any => {
        return {
            width: event.target.width,
            height: event.target.height
        };
    }
    var image = new Image();
    let $loadedImg = fromEvent(image, "load").pipe(take(1), map(mapLoadedImage));
    // Rxjs 4 - let $loadedImg = Observable.fromEvent(image, "load").take(1).map(mapLoadedImage);
    image.src = imageSrc;
    return $loadedImg;
  }

  nationnavyclik(){
    this._router.navigate(['/searchlist', "Nation and the Navy", this.search_type])
  }
  navyhorizonClick(){
    this._router.navigate(['/searchlist', "Navy beyond horizon", this.search_type])
  }
}
