import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import {  FormBuilder, Validators, FormGroup,FormControl } from '@angular/forms';
//import { DeviceService } from '../device.service';
import { Router,ActivatedRoute } from '@angular/router';
import { __await } from 'tslib';
import { MatSnackBar } from '@angular/material/snack-bar';
import { eventForm ,eventmodels } from '../../../models/eventmodels'//'../../../../models/devicemodels';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { EventService } from '../event.service'

@Component({
  selector: 'app-event-edit',
  templateUrl: './event-edit.component.html',
  styleUrls: ['./event-edit.component.scss']
})
export class EventEditComponent implements OnInit {
  filenameinput3: string = "Image 3";
  filenameinput2: string = "Image 2";
  filenameinput1: string = "Image 1";
  filenameinput4: string = "Image 4";
  _file3id: string = null;
  _file2id: string = null;
  _file1id: string = null;
  _file4id: string = null;

  filenameinput5: string = "Image 5";
  filenameinput6: string = "Image 6";
  filenameinput7: string = "Image 7";
  filenameinput8: string = "Image 8";
  _file5id: string = null;
  _file6id: string = null;
  _file7id: string = null;
  _file8id: string = null;

  filenameinput9: string = "Image 9";
  filenameinput10: string = "Image 10";
  filenameinput11: string = "Image 11";
  filenameinput12: string = "Image 12";

  filenameinput13: string = "Image 13";

  _file9id: string = null;
  _file10id: string = null;
  _file11id: string = null;
  _file12id: string = null;

  _file13id: string = null; //video
  Forms: FormGroup;
  selectFormControl = new FormControl('', Validators.required);
  public Editor = ClassicEditor;
  id: any;
  constructor(private snackBar: MatSnackBar,  private cdref: ChangeDetectorRef, private eventService:EventService,
    private formBuilder: FormBuilder, private _router: Router,private eventModels:eventForm,private route: ActivatedRoute) { }

  compareThem(o1, o2): boolean{
      console.log('compare with');
      return o1.name === o2.name;
  }
  defval:any;
  
  ngOnInit() {
    this.Forms = this.eventModels.modelForms;

    this.route.params.subscribe(params => {
      this.id = params['id'];
      console.log("update id--" + params['id']);
      this.eventService.getbyid(this.id).subscribe((data) => {
        this._file4id = data["image4"];
        this._file3id = data["image3"]; //prev val assign
        this._file2id = data["image2"];
        this._file1id = data["image1"];
        this._file5id = data["image5"];
        this._file6id = data["image6"];
        this._file7id = data["image7"];
        this._file8id = data["image8"];
        this._file9id = data["image9"];
        this._file10id = data["image10"];
        this._file11id = data["image11"];
        this._file12id = data["image12"];

        this._file13id = data["video"];
        this.Forms.patchValue(data);
        //this.selectFormControl = new FormControl(data["productgroup"], Validators.required);
       // this.defval = data["productgroup"];
        console.log(this.Forms);
      });
    })
  }

  async FormSubmit() {
    this.Forms.patchValue({
      image1: this._file1id,
      image2: this._file2id,
      image3: this._file3id,
      image4: this._file4id,

      image5: this._file5id,
      image6: this._file6id,
      image7: this._file7id,
      image8: this._file8id,
      image9: this._file9id,
      image10: this._file10id,
      image11: this._file11id,
      image12: this._file12id,

      video: this._file13id
    })
    const formValue = this.Forms.value;
    console.log(formValue);
    await this.eventService.update(this.id, formValue).subscribe(() => {
      console.log("Update req successfull");
      this.snackBar.open('Data Updated Successfully', "Remove", {
        duration: 5000, verticalPosition: 'top', panelClass: ['blue-snackbar']
      });
      this._router.navigate(['/listEvent']);
    },
      error => {
        console.log("error Update", error);
        this.snackBar.open('Update Unsuccessfull', "Remove", {
          duration: 6000, verticalPosition: 'top', panelClass: ['red-snackbar']
        });
      }
    );
  }
  file4id($event) {
    this._file3id = $event; console.log("pic id arrived--" + $event);
  }
  file3id($event) {
    this._file3id = $event; console.log("pic id arrived--" + $event);
  }
  file2id($event) {
    this._file2id = $event; console.log("pic id arrived--" + $event);
  }
  file1id($event) {
    this._file1id = $event; console.log("pic id arrived--" + $event);
  }

  file5id($event) {
    this._file5id = $event; console.log("pic id arrived--" + $event);
  }
  file6id($event) {
    this._file6id = $event; console.log("pic id arrived--" + $event);
  }
  file7id($event) {
    this._file7id = $event; console.log("pic id arrived--" + $event);
  }
  file8id($event) {
    this._file8id = $event; console.log("pic id arrived--" + $event);
  }
  file9id($event) {
    this._file9id = $event; console.log("pic id arrived--" + $event);
  }
  file10id($event) {
    this._file10id = $event; console.log("pic id arrived--" + $event);
  }
  file11id($event) {
    this._file11id = $event; console.log("pic id arrived--" + $event);
  }
  file12id($event) {
    this._file12id = $event; console.log("pic id arrived--" + $event);
  }

  file13id($event) {
    this._file13id = $event; console.log("pic id arrived--" + $event);
  }
}
