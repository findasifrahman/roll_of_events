import { Component, OnInit } from '@angular/core';
import {myarr} from '../../data'
import * as moment from 'moment';
import { Router,ActivatedRoute } from '@angular/router';
import { EventService } from '../../event/event.service'
import { routeurls } from '../../../AllComponent/routeurls/routeurls'
import {FormControl} from '@angular/forms';
import {fromEvent, Observable} from 'rxjs';
import {map, startWith, take} from 'rxjs/operators';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
@Component({
  selector: 'app-template-two',
  templateUrl: './template-two.component.html',
  styleUrls: ['./template-two.component.scss']
})
export class TemplateTwoComponent implements OnInit {
  planClient = new FormControl();
  filteredOptions: Observable<string[]>;
  cnsNameList = [{name:"Captain Nurul Huq, (E)"},
  {name:"Rear Admiral Musharraf Hussain Khan, psc"},
  {name:"Rear Admiral Mahbub Ali Khan, psc"},
  {name:"Rear Admiral Sultan Ahmed"},
  {name:"Rear Admiral Amir Ahmed Mustafa, (SM), psc"},
  {name:"Rear Admiral Mohammad Mohaiminul Islam (SM), ncc "},
  {name:"Rear Admiral Mohammad Nurul Islam ncc, psc "},
  {name:"Rear Admiral Abu Taher, ndu"},
  {name:"Rear Admiral Shah Iqbal Mujtaba, ndc, psc"},
  {name:"Rear Admiral Mohammad Hasan Ali Khan ndc, psc "},
  {name:"Vice Admiral Sarwar Jahan Nizam ndu, psc "},
  {name:"Vice Admiral Zahir Uddin Ahmed NBP, BCGMS, ndc, psc "},
  {name:"Admiral Muhammad Farid Habib, NBP, OSP, BCGM, ndc, psc"},
  {name:"Admiral Mohammad Nizamuddin Ahmed,NBP, OSP, BCGM, ndc, psc"},]

  tiles: any[] = [
    {text: 'One', cols: 3, rows: 2, color: 'lightblue'},
    {text: 'Two', cols: 1, rows: 1, color: 'lightgreen'},
    {text: 'Three', cols: 1, rows: 1, color: 'lightpink'},
    //{text: 'Four', cols: 2, rows: 1, color: '#DDBDF1'},
  ];

  tDate = moment().format('LLLL')

  additional_image_num = "0"

  vidpresent = false
  myarr = [];// = myarr
  categoryNewsArr = []
  selectedCategory = "2020-"
  allvideo = []
  searchres: any
  relatedNews = []
  relatedDate = []
  relatedYear = []
  searchtext = ""
  mainuri = routeurls.BASE_API_URL + "/api/uploads/"//"/api/uploads/"//"http://localhost:5020/api/uploads/";
  totalImageno = 1
  constructor(private route: ActivatedRoute,public _router: Router,private eventService:EventService) {
    this._router.routeReuseStrategy.shouldReuseRoute = () => false;
  }
  showFlag: boolean = false;
  selectedImageIndex: number = -1;
  imageObject=[]//: Array<object>
  rowHeight = "28vh"
  search_date =""
  clients: string[]
  showLightbox(index) {
    this.selectedImageIndex = index;
    this.showFlag = true;
  }

  closeEventHandler() {
      this.showFlag = false;
      this.selectedImageIndex = -1;
  }
  ngOnInit(): void { 
    this.clients = []
    this.planClient.valueChanges.subscribe()
    this.filteredOptions = this.planClient.valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
      );
    for (let i = 0; i<20; i++){
      let ins = localStorage.getItem("usersearch" + i.toString())
      console.log("ins--", ins)
      if(ins)
        this.clients.push(ins)
    }   
    this.route.params.subscribe(params => {
      this.searchtext = params['id'];
      
      //this.planClient.setValue(this.searchtext)
      this.eventService.getbyidwithrelated(this.searchtext).subscribe(posts=>{
        this.search_date = posts.idres.uploadDate
        //posts.relateddate
        // posts.idres
        //posts.relatedyear    
        
        this.getImgSize(this.mainuri +  posts.idres.image1 ).subscribe(val=>{
          //this.getImgSize(this.mainuri +  posts.idres.image2 ).subscribe(val2=>{
          //  this.getImgSize(this.mainuri +  posts.idres.image3 ).subscribe(val3=>{
           //   this.getImgSize(this.mainuri +  posts.idres.image4 ).subscribe(val4=>{
          
          //console.log("image get val--",val)          
          ////////////////////////////////////////////////////////////////////////////////////
            posts.idres.image1 = this.mainuri +  posts.idres.image1
            this.imageObject.push({image:  posts.idres.image1,  title: posts.idres.image1caption})
            if(posts.idres.image2){
              posts.idres.image2 = this.mainuri +  posts.idres.image2
              this.totalImageno = this.totalImageno + 1
              this.imageObject.push({image:  posts.idres.image2,  title: posts.idres.image2caption})
            }
            
            //posts.idres.image3 = this.mainuri +  posts.idres.image1
            //this.imageObject.push({image:  posts.idres.image1,  title: posts.idres.image1caption})
            if(posts.idres.image3){       
              posts.idres.image3 = this.mainuri +  posts.idres.image3
              this.imageObject.push({image:  posts.idres.image3,  title: posts.idres.image3caption})
              
              this.totalImageno = this.totalImageno + 1
            }
            if(posts.idres.image4){
              posts.idres.image4 = this.mainuri +  posts.idres.image4
              this.imageObject.push({image:  posts.idres.image4,  title: posts.idres.image4caption})
              
              this.totalImageno = this.totalImageno + 1
            }
            if(posts.idres.image5){
              posts.idres.image5 = this.mainuri +  posts.idres.image5
              this.imageObject.push({image:  posts.idres.image5, title: posts.idres.image5caption})
              this.additional_image_num = "+0"
              this.totalImageno = this.totalImageno + 1
            }
            if(posts.idres.image6){
              posts.idres.image6 = this.mainuri +  posts.idres.image6
              this.imageObject.push({image:  posts.idres.image6,  title: posts.idres.image6caption})
              this.additional_image_num = "+1"
              this.totalImageno = this.totalImageno + 1
            }
            if(posts.idres.image7){
              posts.idres.image7 = this.mainuri +  posts.idres.image7
              this.imageObject.push({image:  posts.idres.image7,  title: posts.idres.image7caption})
              this.additional_image_num = "+2"
            }
            if(posts.idres.image8){
              posts.idres.image8 = this.mainuri +  posts.idres.image8
              this.imageObject.push({image:  posts.idres.image8, title: posts.idres.image8caption})
              this.additional_image_num = "+3"
              this.totalImageno = this.totalImageno + 1
            }
            if(posts.idres.image9){
              posts.idres.image9 = this.mainuri +  posts.idres.image9
              this.imageObject.push({image:  posts.idres.image9, title: posts.idres.image9caption})
              this.additional_image_num = "+4"
            }
            if(posts.idres.image10){
              posts.idres.image10 = this.mainuri +  posts.idres.image10
              this.imageObject.push({image:  posts.idres.image10, title: posts.idres.image10caption})
              this.additional_image_num = "+5"
              this.totalImageno = this.totalImageno + 1
            }
            if(posts.idres.image11){
              posts.idres.image11 = this.mainuri +  posts.idres.image11
              this.imageObject.push({image:  posts.idres.image11, title: posts.idres.image11caption})
              this.additional_image_num = "+6"
              this.totalImageno = this.totalImageno + 1
            }
            if(posts.idres.image12){
              posts.idres.image12 = this.mainuri +  posts.idres.image12
              this.imageObject.push({image:  posts.idres.image12, title: posts.idres.image12caption})
              this.additional_image_num = "+7"
              this.totalImageno = this.totalImageno + 1
            }
            if(posts.idres.video){
              posts.idres.video == this.mainuri +  posts.idres.video
            }
            posts.idres.date = moment(posts.idres.date).format("ll")
            this.searchres = posts.idres

            if(this.searchres.video){
              this.vidpresent = true
              this.searchres.video = this.mainuri + this.searchres.video
            }
            
            ///////////////////////////////////////////////////////////////
            if(this.totalImageno == 1){
              if(posts.idres.video){
                this.rowHeight = "18vh"
                if(val.height > val.width){
                  this.tiles = [
                    {text: 'One', cols: 2, rows: 2, image:  posts.idres.image1,image1verticle: true},
                    {text: 'two', cols: 2, rows: 2, video:  this.searchres.video,image1verticle: false}
                  ]
                }else{ 
                  this.tiles = [
                    {text: 'two', cols: 2, rows: 2, video:  this.searchres.video},
                    {text: 'One', cols: 2, rows: 2, image: posts.idres.image1}] 
                }
              } else{ 
                this.rowHeight = "32vh"
                if(val.height > val.width){
                  this.tiles = [
                    {text: 'One', cols: 4, rows: 2, image:  posts.idres.image1,image1verticle: true}
                  ]
                }else{ 
                  this.tiles = [
                    {text: 'One', cols: 4, rows: 2, image: posts.idres.image1}] 
                }
              }
            }
            /////////////////////////////////////
            if(this.totalImageno == 2){  
              this.rowHeight = "21vh"
              let image1verticle = false
              let image2verticle = false

              if(posts.idres.video){
                this.getImgSize(posts.idres.image2 ).subscribe(val2=>{
                  if(val.height > val.width){
                    image1verticle = true
                  }
                  if(val2.height > val2.width ){
                    image2verticle = true
                  }
                  this.tiles = [
                    {text: 'One', cols: 3, rows: 2, video:  this.searchres.video},
                    {text: 'two', cols: 1, rows: 1, image:  posts.idres.image1,image1verticle: image2verticle},
                    {text: 'three', cols: 1, rows: 1, image:  posts.idres.image2,image1verticle: image2verticle}
                  ]

                })
              }
              else{
                this.getImgSize(posts.idres.image2 ).subscribe(val2=>{
                    if(val.height > val.width){
                      image1verticle = true
                    }
                    if(val2.height > val2.width ){
                      image2verticle = true
                    }
                    this.tiles = [
                      {text: 'One', cols: 2, rows: 2, image:  posts.idres.image1,image1verticle: image1verticle},
                      {text: 'two', cols: 2, rows: 2, image:  posts.idres.image2,image1verticle: image2verticle}
                    ]
                })
              }
            }
            //////////////////////////////////////////////////////
            if(this.totalImageno == 3){
              let image1verticle = false
              let image2verticle = false
              let image3verticle = false
              if(posts.idres.video){
                this.rowHeight ="18vh"
                this.getImgSize(posts.idres.image2 ).subscribe(val2=>{
                  this.getImgSize(posts.idres.image3 ).subscribe(val3=>{
                    if(val.height > val.width){
                      image1verticle = true                
                      //posts.idres.image1verticle = true
                    }
              
                    if(val2.height > val2.width){ image2verticle = true }
                    if(val3.height > val3.width){ image3verticle = true }
                    this.tiles = [
                      {text: 'One', cols: 3, rows: 3, video:  this.searchres.video},
                      {text: 'Two', cols: 1, rows: 1,image: posts.idres.image1,image1verticle: image1verticle},
                      {text: 'Three', cols: 1, rows: 1,image: posts.idres.image2, image1verticle: image2verticle},
                      {text: 'Four', cols: 1, rows: 1,image: posts.idres.image3, image1verticle: image3verticle},
                    ]
                  })
                })
              }
              else{
                this.getImgSize(posts.idres.image2 ).subscribe(val2=>{
                  this.getImgSize(posts.idres.image3 ).subscribe(val3=>{
                    if(val.height > val.width){
                      image1verticle = true                
                      //posts.idres.image1verticle = true
                    }
              
                    if(val2.height > val2.width){ image2verticle = true }
                    if(val3.height > val3.width){ image3verticle = true }
                    this.tiles = [
                      {text: 'One', cols: 3, rows: 2, image:  posts.idres.image1,image1verticle: image1verticle},
                      {text: 'Two', cols: 1, rows: 1,image: posts.idres.image2,image1verticle: image2verticle},
                      {text: 'Three', cols: 1, rows: 1,image: posts.idres.image3, image1verticle: image3verticle},
                    ]
                  })
                })
              }
              //posts.idres.image1verticle = false
            }
            ///////////////////////////////////////////////////////////////
            if(this.totalImageno == 4){
              if(posts.idres.video){
                this.rowHeight = "19vh"
                let image1verticle = false
                let image2verticle = false
                let image3verticle = false
                let image4verticle = false
                this.getImgSize(posts.idres.image2 ).subscribe(val2=>{
                  this.getImgSize(posts.idres.image3 ).subscribe(val3=>{
                    this.getImgSize(posts.idres.image4 ).subscribe(val4=>{
                      if(val.height > val.width){
                        image1verticle = true                
                        //posts.idres.image1verticle = true
                      }

                      if(val2.height > val2.width){ image2verticle = true }
                      if(val3.height > val3.width){ image3verticle = true }
                      if(val4.height > val4.width){ image4verticle = true }
                      this.tiles = [
                        {text: 'One', cols: 4, rows: 3, video: this.searchres.video},
                        {text: 'Two', cols: 1, rows: 1,image: posts.idres.image1,image1verticle: image1verticle},
                        {text: 'Three', cols: 1, rows: 1,image: posts.idres.image2, image1verticle: image2verticle},
                        {text: 'Four', cols: 1, rows: 1,image: posts.idres.image3, image1verticle: image3verticle},
                        {text: 'Five', cols: 1, rows: 1,image: posts.idres.image4, image1verticle: image4verticle}
                      ]
                    })
                  })
                })
              }else{
                this.rowHeight = "19vh"
                let image1verticle = false
                let image2verticle = false
                let image3verticle = false
                let image4verticle = false
                this.getImgSize(posts.idres.image2 ).subscribe(val2=>{
                  this.getImgSize(posts.idres.image3 ).subscribe(val3=>{
                    this.getImgSize(posts.idres.image4 ).subscribe(val4=>{
                          if(val.height > val.width){
                            image1verticle = true                
                            //posts.idres.image1verticle = true
                          }
                    
                          if(val2.height > val2.width){ image2verticle = true }
                          if(val3.height > val3.width){ image3verticle = true }
                          if(val4.height > val4.width){ image4verticle = true }
                          this.tiles = [
                            {text: 'One', cols: 3, rows: 3, image:  posts.idres.image1,image1verticle: image1verticle},
                            {text: 'Two', cols: 1, rows: 1,image: posts.idres.image2,image1verticle: image2verticle},
                            {text: 'Three', cols: 1, rows: 1,image: posts.idres.image3, image1verticle: image3verticle},
                            {text: 'Four', cols: 1, rows: 1,image: posts.idres.image4, image1verticle: image4verticle}
                          ]
                        
                    })
                  })
                })
              }
            }
            ///////////////////////////////////////////////////////////////
            if(this.totalImageno >= 5){
              if(posts.idres.video){
                this.rowHeight = "19vh"
                let image1verticle = false
                let image2verticle = false
                let image3verticle = false
                let image4verticle = false
                this.getImgSize(posts.idres.image2 ).subscribe(val2=>{
                  this.getImgSize(posts.idres.image3 ).subscribe(val3=>{
                    this.getImgSize(posts.idres.image4 ).subscribe(val4=>{
                          if(val.height > val.width){
                            image1verticle = true                
                            //posts.idres.image1verticle = true
                          }
                    
                          if(val2.height > val2.width){ image2verticle = true }
                          if(val3.height > val3.width){ image3verticle = true }
                          if(val4.height > val4.width){ image4verticle = true }
                          this.tiles = [
                            {text: 'One', cols: 4, rows: 3,video: this.searchres.video},
                            {text: 'Two', cols: 1, rows: 1,image: posts.idres.image1,image1verticle: image1verticle},
                            {text: 'Three', cols: 1, rows: 1,image: posts.idres.image2, image1verticle: image2verticle},
                            {text: 'Four', cols: 1, rows: 1,image: posts.idres.image3, image1verticle: image3verticle},
                            {text: 'Five', cols: 1, rows: 1,image: posts.idres.image4, image1verticle: image4verticle,additional_image: true}
                          ]
                        
                    })
                  })
                })
              }else{
                  this.rowHeight = "23vh"
                  let image1verticle = false
                  let image2verticle = false
                  let image3verticle = false
                  let image4verticle = false
                  let image5verticle = false
                  this.getImgSize(posts.idres.image2 ).subscribe(val2=>{
                    this.getImgSize(posts.idres.image3 ).subscribe(val3=>{
                      this.getImgSize(posts.idres.image4 ).subscribe(val4=>{
                        this.getImgSize(posts.idres.image5).subscribe(val5=>{
                            if(val.height > val.width){
                              image1verticle = true                
                              //posts.idres.image1verticle = true
                            }
                      
                            if(val2.height > val2.width){ image2verticle = true }
                            if(val3.height > val3.width){ image3verticle = true }
                            if(val4.height > val4.width){ image4verticle = true }
                            if(val5.height > val5.width){ image5verticle = true }
                            this.tiles = [
                              {text: 'One', cols: 4, rows: 3, image:  posts.idres.image1,image1verticle: image1verticle},
                              {text: 'Two', cols: 1, rows: 1,image: posts.idres.image2,image1verticle: image2verticle},
                              {text: 'Three', cols: 1, rows: 1,image: posts.idres.image3, image1verticle: image3verticle},
                              {text: 'Four', cols: 1, rows: 1,image: posts.idres.image4, image1verticle: image4verticle},
                              {text: 'Five', cols: 1, rows: 1,image: posts.idres.image4, image1verticle: image5verticle,additional_image: true}
                            ]
                          })
                      })
                    })
                  })
              }
            }
            ///////////////////////////////////////////////////////////////

        })
        //console.log(posts)
        let temparr = []
        posts.relateddate.map((mapval,index)=>{
          mapval.image1 = this.mainuri + mapval.image1
          mapval.tdate = moment(mapval.date).format("ll")

          this.getImgSize(mapval.image1 ).subscribe(val=>{
            if(val.height > val.width){
              mapval.isverticle = true
            }
            else{
              mapval.isverticle = false
            }
            temparr.push(mapval)
            if(index == posts.relateddate.length -1){
              this.relatedDate = temparr
            }
          })

         
        })
        /////////////////////////////////////////////////
        let temparr2 = []
        posts.relatedyear.map((mapval,index)=>{
          mapval.image1 = this.mainuri + mapval.image1
          mapval.tdate = moment(mapval.date).format("ll")

          this.getImgSize(mapval.image1 ).subscribe(val=>{
            if(val.height > val.width){
              mapval.isverticle = true
            }
            else{
              mapval.isverticle = false
            }
            temparr2.push(mapval)
            if(index == posts.relatedyear.length -1){
              this.relatedYear = temparr2
            }
          })


        })
        let temparr3 = []
        posts.relatednews.map((mapval,index)=>{
          mapval.image1 = this.mainuri + mapval.image1
          mapval.smtitle = mapval.title.substr(0,35) + " ..."
          this.getImgSize(mapval.image1 ).subscribe(val=>{
            console.log("image get val--",val)
            if(val.height > val.width){
              mapval.isverticle = true
            }
            else{
              mapval.isverticle = false
            }
            temparr3.push(mapval)


            if(index == posts.relatednews.length -1){
              this. relatedNews = temparr3
            }
          })
          
          
        })
        //////////////////////////////////////////////////////


      })

      //////////////////
    })

  }
  private _filter(value: string): string[] {
    //console.log("insiede filter");
    const filterValue = value.toLowerCase();

    return this.clients.filter(clients => clients.toLowerCase().includes(filterValue));
  }
  category71(){
    this.categoryNewsArr =  this.myarr.map(mapval=>{
      if(mapval.category==1971){
        return mapval
      }else{
        return null
      }
    })
    this.categoryNewsArr = this.categoryNewsArr.filter(x=> x != null )
  }
  category80(){
    this.categoryNewsArr =  this.myarr.map(mapval=>{
      if(mapval.category==1980){
        return mapval
      }else{
        return null
      }
    })
    this.categoryNewsArr = this.categoryNewsArr.filter(x=> x != null )
  }
  category90(){
    this.categoryNewsArr =  this.myarr.map(mapval=>{
      if(mapval.category==1990){
        return mapval
      }else{
        return null
      }
    })
    this.categoryNewsArr = this.categoryNewsArr.filter(x=> x != null )
  }
  category00(){
    this.categoryNewsArr =  this.myarr.map(mapval=>{
      if(mapval.category==2000){
        return mapval
      }else{
        return null
      }
    })
    this.categoryNewsArr = this.categoryNewsArr.filter(x=> x != null )
  }
  category10(){
    this.categoryNewsArr =  this.myarr.map(mapval=>{
      if(mapval.category==2010){
        return mapval
      }else{
        return null
      }
    })
    this.categoryNewsArr = this.categoryNewsArr.filter(x=> x != null )
  }
  category20(){
    this.categoryNewsArr =  this.myarr.map(mapval=>{
      if(mapval.category==2020){
        return mapval
      }else{
        return null
      }
    })
    this.categoryNewsArr = this.categoryNewsArr.filter(x=> x != null )
  }
  FormSubmit1(){
    this._router.navigate(['/searchlist', this.planClient.value,this.search_type]);
    //this._router.navigate(['/viewtemptwo', id]);
  }
  FormSubmit(id){
    //this._router.navigate(['/searchlist', this.planClient.value]);
    this._router.navigate(['/viewtemptwo', id]);
  }
  Bangabandhu(){
    this._router.navigate(['/viewtemptwo', 10]);
  }
  gotohome(){
    this._router.navigate(['/']);
  }
  gotoid(id){
    this._router.navigate(['/viewtemptwo', id]);
  }
  _yearClick(param){
    //this._router.navigate(['/yearsearchresult', param]);
    console.log("paramm--", param)
    this._router.navigate(['/searchlist', "yearsearch:" + param, this.search_type]);
  }
  ///////////// modal slideshow
  display = "none";
  imageUrl = ""
  imageindex = 0
  isverticalmodal = false
  openModal() {
    let modal_t  = document.getElementById('modal_1')
    var modalImg = document.getElementById("img01");
    modal_t.style.display = "block";

    this.getImgSize(this.imageObject[this.imageindex].image ).subscribe(val=>{       
      if(val.height > val.width){
        this.isverticalmodal = true
      }else{
        this.isverticalmodal = false
      }
      this.imageUrl = this.imageObject[this.imageindex].image;
      var captionText = document.getElementById("caption");
      captionText.innerHTML = this.imageObject[this.imageindex].title;
    })

    //this.display = "block";
  }
  modalclose(){
    let modal  = document.getElementById('modal_1')
    modal.style.display = "none";
    this.imageindex = 0
  }
  
  zoom_index =0
  zoomIn(){
    var modalImg = document.getElementById("img01");
    if(this.zoom_index == 0){
      modalImg.style.transform = "scale(1.2,1.2)"
      this.zoom_index = 1
    }else if(this.zoom_index == 1){
      modalImg.style.transform = "scale(1.4,1.4)"
      this.zoom_index = 2
    }else{
      modalImg.style.transform = "scale(1.6,1.6)"
      this.zoom_index = 3
    }
  }
  zoomOut(){
    var modalImg = document.getElementById("img01");
    if(this.zoom_index == 3){
      modalImg.style.transform = "scale(1.4,1.4)"
      this.zoom_index = 2
    }else if(this.zoom_index == 2){
      modalImg.style.transform = "scale(1.2,1.2)"
      this.zoom_index = 1
    }else{
      modalImg.style.transform = "scale(1,1)"
      this.zoom_index = 0
    }
  }
  downloadImage() {
               const a = document.createElement('a');
                a.href = this.imageUrl//URL.createObjectURL(res);
                a.download = this.imageUrl;
                document.body.appendChild(a);
                a.click();
           
  }
  plusSlides(){
    if(this.imageindex >= this.totalImageno - 1){
      let modal  = document.getElementById('modal_1')
      this.imageindex = 0
      modal.style.display = "none";
      
    }else{
      this.imageindex = this.imageindex + 1

      
      this.getImgSize(this.imageObject[this.imageindex].image ).subscribe(val=>{       
        if(val.height > val.width){
          this.isverticalmodal = true
        }else{
          this.isverticalmodal = false
        }
        this.imageUrl = this.imageObject[this.imageindex].image;
        var captionText = document.getElementById("caption");
        captionText.innerHTML = this.imageObject[this.imageindex].title;
      })
    }

  }
  minusSlides(){
    if(this.imageindex > 0){
      this.imageindex = this.imageindex - 1

      this.getImgSize(this.imageObject[this.imageindex].image ).subscribe(val=>{       
        if(val.height > val.width){
          this.isverticalmodal = true
        }else{
          this.isverticalmodal = false
        }
        this.imageUrl = this.imageObject[this.imageindex].image;
        var captionText = document.getElementById("caption");
        captionText.innerHTML = this.imageObject[this.imageindex].title;

      })
    }
  }

  getImgSize(imageSrc: string): Observable<any> {
    let mapLoadedImage = (event): any => {
        return {
            width: event.target.width,
            height: event.target.height
        };
    }
    var image = new Image();
    let $loadedImg = fromEvent(image, "load").pipe(take(1), map(mapLoadedImage));
    // Rxjs 4 - let $loadedImg = Observable.fromEvent(image, "load").take(1).map(mapLoadedImage);
    image.src = imageSrc;
    return $loadedImg;
  }
  ////////////////////
  nextArticle(){//this.search_date
    this.eventService.getnextarticle(this.searchtext).subscribe(posts=>{
      console.log("next article--", posts)
      if(posts[0]){
        this._router.navigate(['/viewtemptwo', posts[0].id]);
      }
    })
  }
  prevArticle(){//this.search_date
    this.eventService.getprevarticle(this.searchtext).subscribe(posts=>{
      console.log("next article--", posts)
      if(posts[0]){
        this._router.navigate(['/viewtemptwo', posts[0].id]);
      }
    })
  }
  bntStyle1: string = "btn-default";
  bntStyle2: string = "btn-default";
  search_type = "all"
  videoClick(){
    this.bntStyle1 = 'btn-default';
    this.bntStyle2 = 'btn-change';
    this.search_type = "video"
  }
  imageClick(){
    this.bntStyle1 = 'btn-change';
    this.bntStyle2 = 'btn-default';
    this.search_type = "image"
  }
  defaultClick(){
    this.bntStyle1 = 'btn-default';
    this.bntStyle2 = 'btn-default';
    this.search_type = "all"
  }
  nationnavyclik(){
    this._router.navigate(['/searchlist', "Nation and the Navy", this.search_type])
  }
  navyhorizonClick(){
    this._router.navigate(['/searchlist', "Navy beyond horizon", this.search_type])
  }
  dateval(id){
    this._router.navigate(['/searchlist', "datesearch:" + id, this.search_type])
  }
}
