export const routeurls = Object.freeze({
  BASE_API_URL: 'http://localhost:5020',//'http://18.139.46.224:5022',//'http://api.autosol.xyz:5022',//'http://18.136.57.177:5022',//'http://103.218.25.96:5021',//'http://localhost:8086'
  PICTURE_VIEW_URL: "/picture/getpic?picid=",
  FILE_UPLOAD_BASE_URL:"/picture/upload",
  FILE_DELETE_BASE_URL:"/picture/delete",
  File_UPLOAD_STATIC_VIEW_URL: "/api/uploads/",
  USER_API_BASE_URL: "/api/userModels",
  SPEED_LIMIT_BASE_URL: "/api/employee/updatespeedlimit",
  LOGIN_API_BASE_URL: "/api/login",
  EVENT_ADD_API_BASE: '/api/event',
  SYNONYM_API_BASE: '/api/synonym'

  //... more of your variable
});
